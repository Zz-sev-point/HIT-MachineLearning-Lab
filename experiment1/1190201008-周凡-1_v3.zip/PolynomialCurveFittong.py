import numpy as np
import matplotlib.pyplot as plt
import random

#生成样本并获得训练集，N为样本总个数，ratio反应训练集比例
# mu和sigma分别为高斯噪声的参数
def getData(N,ratio,mu,sigma):
    X = np.arange(0,1,1/N)
    Y = np.sin(X*2*np.pi)
    #训练集
    X1 = []
    Y1 = []
    #验证集
    X2 = []
    Y2 = []
    #加入高斯噪声
    for i in range(N):
        Y[i] += random.gauss(mu, sigma)
    #获得训练集
    for i in range(N):
        if(i%ratio!=0):
            X1.append(X[i])
            Y1.append(Y[i])
        else:
            X2.append(X[i])
            Y2.append(Y[i])
    return X1,Y1
            
#获得矩阵X,m为样本数,n为参数个数
def getX(X0,m,n):
    X = np.zeros((m,n))
    for i in range(m):
        for j in range(n):
            X[i][j] = X0[i]**j
    return X

#获得矩阵Y,m为样本数
def getY(Y0,m):
    Y = np.zeros((m,1))
    for i in range(m):
        Y[i][0] = Y0[i]
    return Y
    
#无正则项的解析解,m为样本数,n为参数个数
def nonRegAnalyse(X0,Y0,m,n):
    #获得m*n的X矩阵
    X = getX(X0,m,n)
    #获得m*1的Y矩阵
    Y = getY(Y0,m)
    return np.dot(np.dot(np.linalg.inv(np.dot(X.T, X)), X.T), Y)

#有正则项的解析解,m为样本数,n为参数个数，lamda为惩罚项系数
def regAnalyse(X0,Y0,m,n,lamda):
    #获得m*n的X矩阵
    X = getX(X0,m,n)
    #获得m*1的Y矩阵
    Y = getY(Y0,m)
    l = lamda*np.eye(n)
    return np.dot(np.dot(np.linalg.inv(np.dot(X.T, X) + l), X.T), Y)

#代价函数
def loss(X,Y,w):
    M = np.dot(X,w)-Y
    cost = np.dot(M.T,M)/2
    return cost

#梯度下降法,m为样本数,n为参数个数，lamda为惩罚项系数
#step为步长，epsilon为迭代误差
def gradientDscend(X0,Y0,m,n,lamda,step,epsilon):
    X = getX(X0,m,n)
    Y = getY(Y0,m)
    w = np.zeros((n,1))
    #记录损失函数值的变化情况
    losslist = []
    counterlist = []
    i = 1
    while 1:
        pderivative = np.dot(X.T, np.dot(X, w)) - np.dot(X.T, Y) + lamda*w
        print(np.dot(pderivative.T, pderivative))
        loss0 = abs(loss(X, Y, w))
        losslist.append(loss0)
        counterlist.append(i)
        w = w - step*pderivative
        loss1 = abs(loss(X,Y,w))
        i = i+1
        #若损失函数以及偏导收敛则结束循环
        if abs(loss0-loss1)<epsilon and np.dot(pderivative.T, pderivative)<epsilon:
            break
    return w,losslist,counterlist

#共轭梯度法,m为样本数,n为参数个数，lamda为惩罚项系数
# Q为二次函数的二次项系数矩阵，b为一次项系数矩阵
def conjugateGradient(X0,Y0,m,n,lamda,Q,b):
    # X = getX(X0,m,n)
    # Y = getY(Y0,m)
    # Q = np.dot(X.T, X) + lamda*np.eye(n)
    # b = np.dot(X.T, Y)
    #初始化
    w = np.zeros((n,1))
    r = -b
    d = np.zeros((n,1))
    for i in range(n):
        #计算残差向量
        rp = r
        r = np.dot(Q, w) - b
        #计算方向向量
        gama = np.dot(r.T, r)/np.dot(rp.T, rp)
        d = -r + gama*d
        #计算步长
        l = -np.dot(d.T, r)/np.dot(np.dot(d.T, Q), d)
        #更新解向量
        w = w + l*d
    return w

#常量，参数，数据集
N = 15
N1 = 10
ratio = 3
n = 9
lamda = 0.0001
step = 0.1
epsilon = 1e-7
X1,Y1 = getData(N, ratio, 0, 0.1)
#绘制标准正弦
MAX = 1000
X0 = np.arange(0,1,2/MAX)
Y0 = np.sin(X0*2*np.pi)
X = np.arange(0, 1, 1/MAX)
Xn = getX(X,MAX,n)

#解析解
w1 = nonRegAnalyse(X1, Y1, N1, n)
w2 = regAnalyse(X1, Y1, N1, n,lamda)
Y1n = np.dot(Xn, w1)
Y2n = np.dot(Xn, w2)
plt.plot(X1,Y1,linestyle='',color='k',marker='o',label="sample set")
plt.plot(X,Y1n,linestyle='-',color='r', marker='', label="without punishment")
plt.plot(X,Y2n,linestyle='-',color='b', marker='', label="with punishment")
plt.plot(X0,Y0,linestyle='-',color='y', marker='', label="sin()")
plt.legend(loc='upper right')
plt.xlabel("x")
plt.ylabel("y")
plt.title("degree="+str(n)+", lamda="+str(lamda))
print(w1.T)
print(w2.T)
plt.show()

#共轭梯度法
Xm = getX(X1,N1,n)
Ym = getY(Y1,N1)
Q = np.dot(Xm.T, Xm) + lamda*np.eye(n)
b = np.dot(Xm.T, Ym)
w3 = conjugateGradient(X1, Y1, N1, n, lamda, Q, b)
Y3n = np.dot(Xn, w3)
plt.plot(X1,Y1,linestyle='',color='k',marker='o',label="sample set")
plt.plot(X,Y3n,linestyle='-',color='r', marker='', label="conjugate gradient")
plt.plot(X0,Y0,linestyle='-',color='y', marker='', label="sin()")
plt.legend(loc='upper right')
plt.xlabel("x")
plt.ylabel("y")
plt.title("degree="+str(n)+", lamda="+str(lamda))
plt.show()

#梯度下降法
w4,losslist,counterlist = gradientDscend(X1, Y1, N1, n, lamda, step, epsilon)
Y4n = np.dot(Xn, w4)
plt.plot(X1,Y1,linestyle='',color='k',marker='o',label="sample set")
plt.plot(X,Y4n,linestyle='-',color='r', marker='', label="gradient descent")
plt.plot(X0,Y0,linestyle='-',color='y', marker='', label="sin()")
plt.legend(loc='upper right')
plt.xlabel("x")
plt.ylabel("y")
plt.title("degree="+str(n)+", lamda="+str(lamda)+", step="+str(step)+", epsilon="+str(epsilon))
plt.show()
counterlist = getY(counterlist, len(counterlist))
losslist = getY(losslist, len(losslist))
plt.plot(counterlist,losslist,linestyle='-',color='k',marker='')
plt.xlabel("Time")
plt.ylabel("Lost")
plt.title("The Losses of Gradient Descent")
plt.show()