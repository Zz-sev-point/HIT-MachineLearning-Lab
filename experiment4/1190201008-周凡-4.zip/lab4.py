import numpy as np
import cv2
import scipy
import os
from PIL import Image
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
 
def generate_data(dimension, amount):
    if dimension == 2:
        mean = [1, 2]
        cov = [[1, 0], [0, 0.01]]
    elif dimension == 3:
        mean = [1, 2, 3]
        cov = [[0.01, 0, 0], [0, 1, 0], [0, 0, 1]]
    data = []
    for i in range(amount):
        data.append(np.random.multivariate_normal(mean,cov).tolist())
    return np.array(data)      
 
def pca(data, new_dimension):
    amount, dimension = data.shape
    mean = 1/amount * np.sum(data, axis=0) # get mean
    decenttralize_data = data - mean # decentrelize
    print('decentrelize')
    cov = np.dot(decenttralize_data.T, decenttralize_data) # get CovMatrix
    eigenvalue, eigenvector = np.linalg.eig(cov) # get eigenvalue & eigenvector
    print('eigenvalue')
    min_dimension = np.argsort(eigenvalue)
    eigenvector = np.delete(eigenvector, min_dimension[:dimension-new_dimension], axis=1)
    return eigenvector, mean

# calculate single SNR
def snr_single(original_data, pca_data):
    d = (original_data-pca_data)**2
    s = np.sqrt(np.mean(d))
    return 20*np.log10(255.0/s)

# calculate all SNRs and give a graph
def snr(data, dimension):
    ans = []
    x = []
    for i in range(1, 20):
        ev, mean = pca(data, i)
        pca_data = ((data-mean).dot(ev)).dot(ev.T) + mean
        temp = np.abs(np.mean([snr_single(data[j], pca_data[j]) for j in range(len(data))]))
        print(i, temp)
        ans.append(temp)
        x.append(i)
    plt.plot(x, ans)
    plt.xlabel('dimension')
    plt.ylabel('SNR')
    plt.title('SNR-Dimension')
    plt.show()

def show(data, pca_data, dimension):
    if dimension == 2:
        plt.scatter(data[:,0], data[:,1], label='Original Data', color='blue')
        plt.scatter(pca_data[:,0], pca_data[:,1], label='PCA Data', color='red')
    elif dimension == 3:
        fig = plt.figure()
        ax = Axes3D(fig)
        ax.scatter(data[:,0], data[:,1], data[:,2], label='Original Data', color='blue')
        ax.scatter(pca_data[:,0], pca_data[:,1], pca_data[:,2], label='PCA Data', color='red')
    plt.legend()
    plt.show()
    
def load_data(path, size):
    imgs = os.listdir(path)
    data = []
    for i in imgs:
        img = np.array(cv2.imread(os.path.join(path, i)))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = img.reshape(size)
        data.append(img)
    return np.array(data), imgs

def save_data(path, x, y, data, imgs):
    size = np.size(data, axis=0)
    for i in range(size):
        print(data[i])
        img = np.uint8(data[i]).reshape(x,y)
        gray_img = Image.fromarray(img)
        gray_img.save(os.path.join(path, imgs[i]))
        # rgb_img = np.zeros((x,y,3))
        # rgb_img[:,:,2] = img
        # cv2.imwrite(os.path.join(path, imgs[i]), rgb_img)
    print("Done!")

def show_data(x, y, data):
    size = np.size(data, axis=0)
    for i in range(size):
        print(data[i])
        img = np.uint16(data[i]).reshape(x,y)
        gray_img = Image.fromarray(img)
        gray_img.show()
    
# generate data
dimension = 3
amount = 100    
data = generate_data(dimension, amount)
ev, mean = pca(data, dimension-1)
pca_data = ((data-mean).dot(ev)).dot(ev.T) + mean
print(pca_data)
show(data, pca_data, dimension)

# face images
data, imgs = load_data('./face/data', 2500)
print('load data')
ev, mean = pca(data, 5)
print(ev,mean)
pca_data = ((data-mean).dot(ev)).dot(ev.T) + mean
show_data(50, 50, pca_data)
save_data('./face/pca', 50, 50, pca_data, imgs)

# SNR calculate
# snr(data, 2500)